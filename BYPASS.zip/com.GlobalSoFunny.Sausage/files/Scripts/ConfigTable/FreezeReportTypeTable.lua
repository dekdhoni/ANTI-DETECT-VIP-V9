local FreezeReportTypeTable = class({}, Assets.req("Scripts.ConfigTable.Base.FreezeReportTypeTableBase"))

--------------------------------------------自动生成--------------------------------------------

return FreezeReportTypeTable
