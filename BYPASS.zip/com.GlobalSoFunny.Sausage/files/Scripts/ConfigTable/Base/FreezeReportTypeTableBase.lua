



return FreezeReportTypeTableBase