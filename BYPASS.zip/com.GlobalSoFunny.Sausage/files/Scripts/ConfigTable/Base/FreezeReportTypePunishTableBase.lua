



return FreezeReportTypePunishTableBase