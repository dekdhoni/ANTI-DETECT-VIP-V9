



return ReportTypeTableBase