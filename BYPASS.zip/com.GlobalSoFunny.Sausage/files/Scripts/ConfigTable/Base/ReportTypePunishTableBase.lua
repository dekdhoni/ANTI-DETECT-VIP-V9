



return ReportTypePunishTableBase