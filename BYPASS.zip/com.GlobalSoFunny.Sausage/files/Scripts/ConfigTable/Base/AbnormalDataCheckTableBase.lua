



return AbnormalDataCheckTableBase