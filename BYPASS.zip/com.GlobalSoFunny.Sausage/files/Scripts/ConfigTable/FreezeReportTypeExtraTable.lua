local FreezeReportTypeExtraTable = class({}, Assets.req("Scripts.ConfigTable.Base.FreezeReportTypeExtraTableBase"))

--------------------------------------------自动生成--------------------------------------------

return FreezeReportTypeExtraTable
